# 缺陷详情（confirmed）

> 仅含 `verdict=confirmed`。`rejected` 记录见 `REPORT.md`，未覆盖缺口见 `NEEDS-VALIDATION.md`。

---

## fp-authcode-bruteforce — high

**MCP 面授权码为 6 位纯数字且可无限次离线枚举，agent 可绕过人工审批自行部署自动化**

### 边界与结果

| 项 | 内容 |
|---|---|
| 低信任主体 | LLM agent（已获本地 MCP stdio 调用权、持有含 `write` scope 令牌） |
| 接受的输入／动作 | `tools/call` 中 `af_save` 的 `arguments.auth_code` |
| 预期控制 | `af_mcp.py:167`「MCP 面绝不注册 approve（agent 不能自批）」；`af_service.py:490`「reviewer 硬编码 human」 |
| 跨越的边界 | 人工审批 |
| 受影响资源 | 生产归档中的自动化 IR（最终可驱动真实设备动作） |
| 已证实结果 | 第 245,360 次尝试命中有效授权码；命中后走路径 A 直接部署，`deployed_via="auth_code"` |

### 根因

授权码承担「人审替代物」的安全职责，三个属性却按「便于人口述」的 UX 目标设计：

| 属性 | 实际实现 | 应有 |
|---|---|---|
| 熵 | 6 位纯数字 = 10⁶（`af_auth.py:318`） | 不可枚举 |
| 生命周期 | `validate()` 不消耗、无失败计数、无锁定（`af_auth.py:502-511`）；`kind="long"` 永不过期 | 一次性消耗 + 失败锁定 |
| 通道 | `af_mcp.py` 全文无 `RateLimiter`/`limiter` | 限流 |

`AuthCode` dataclass 只有 `code/kind/created_at/expires_at/revoked`——**没有 `consumed`/`failed_attempts`/`locked_until`**。对比同文件 `PairCode` 明确有 `consumed` 且 `PairCodeStore.consume()` 会置位：授权码从**数据模型层面**缺失消耗语义，不是临时疏漏而是设计取向。

### 完整路径

```
agent 发起 tools/call af_save，arguments 含 auth_code
   │  dispatch()（af_mcp.py:791）只做工具名查找 + _guard scope 门，
   │  不校验 arguments 与 inputSchema 一致性 → 未声明的 auth_code 实际可传入
   ▼
_t_save()（af_mcp.py:180）auth_code = (args.get("auth_code") or "").strip()
   ▼
AuthCodeStore.validate()（af_auth.py:502）
   仅 _codes.get(code) → 判存在/未撤销/未过期，无副作用
   ▼
【路径 A】af_mcp.py:185-191
   res = svc.submit_pending(...)                 # 先入队
   applied = svc.approve_pending(                # 同一调用栈内立即批准
       store, op_id,
       reviewer=f"auth_code:{auth_code[:2]}" + "***")
   applied["deployed_via"] = "auth_code"
   ▼
IR 直接落盘部署 —— 人工审批被完全跳过
```

### 证据（`agents/hunter-local-1/artifacts/authcode-bruteforce.txt`）

```
人创建: 长期码=750188 (kind=long)  短期码=245359 (kind=short,5min)
长期码记录: {"code":"750188","kind":"long","created_at":...,"expires_at":null,"revoked":false}
[1] 码空间: 6 位纯数字 (_rand6) = 10^6 = 1,000,000
[2] validate 是否消耗: [True, True, True, True, True] → 不消耗，可无限重试
[3] 长期码 expires_at: None → 永不过期
[4] af_mcp.py 含 RateLimiter: False | 含 limiter: False → MCP stdio 面无限速
[5] validate 吞吐: 1,955,089 次/秒 | 穷举 10^6: 0.51 秒
[6] 实际枚举: 第 245,360 次命中 code=245359
```

**关键性质**：`AuthCodeStore._load()` 每次读本地 JSON，**枚举完全在 agent 进程内完成**——无网络往返、不触服务端日志、不被失败计数捕获，服务端完全不可观测。

### 加重情节

1. **注释即护栏失效**：`af_mcp.py:167`「MCP 面绝不注册 approve」与紧随其后的 v1.9.0 授权码路径直接矛盾
2. **服务层防护被伪 reviewer 绕过**：`_t_save` 传 `reviewer=f"auth_code:XX***"`，因 `reviewer != submitter` 不触发 `af_service.py:500` 自批检查
3. **schema 未声明却可用**：`af_save` 的 inputSchema 无 `auth_code`，`dispatch()` 不校验即透传，造成"看起来不可用、实际可用"的认知盲区

### 前置条件（经两轮独立验证补充）

| # | 条件 | 说明 |
|---|---|---|
| 1 | 本地 MCP stdio 调用权 | 用户本地派生 `forge mcp`，无网络监听端口 |
| 2 | 含 `write` scope 令牌 | `af_mcp.py:725` 注册 `scope="write"`（工具名 `"af_save"` 在 `:709`）。**正常使用场景默认成立** |
| 3 | 归档所有权 | `af_service.py:376-381` 在 `prev_owner != owner` 时抛 403 |
| 4 | 通过静态扫描 | 路径 A 经 `submit_pending` → `StaticScanner`（`af_service.py:447-454`） |
| 5 | 存在有效授权码 | 人类此前生成过长期码或短期码 |
| 6 | 时间窗口 | 短期码 5–30 分钟压缩收益；长期码无人值守时收益最大 |

**关于 likelihood=medium 的裁决**：验证者曾建议下调 `low`（条件链长）。本记录维持 `medium`——条件 1、2、5 在**设计使用场景下默认成立**，不是额外利用步骤而是使用场景本身；一旦成立攻击成本趋零且不可观测。以"需满足若干默认条件"为由压到 low，会系统性低估此类"设计即漏洞"的本地通道风险。

### 严重度

| 维度 | 值 | 理由 |
|---|---|---|
| likelihood | medium | 见上 |
| impact | high | 完全击败显式声明的安全控制；受静态扫描与所有权隔离约束，非远程未认证执行 |
| **overall** | **high** | 符合「actor fully defeats an explicit security control with real consequences」；未超已证实影响 |

### 最小有效修复

**优先级**：① 消耗 + 增大熵（最根本）→ ② 失败计数与软锁定（兜底）→ ③ MCP 限流（纵深防御，非主修复）

#### 1. `src/autoforge/af_auth.py`

```python
# ① 增大熵（建议同步重命名 _rand6 -> _rand8 并改 docstring）
def _rand6() -> str:
    return "".join(secrets.choice("0123456789") for _ in range(8))   # 6 -> 8 位

# ② AuthCode 增加字段
@dataclass
class AuthCode:
    code: str; kind: str; created_at: float; expires_at: float | None
    revoked: bool = False
    failed_attempts: int = 0          # 新增
    locked_until: float | None = None # 新增

# ③ 新增方法（现有仅 create/validate/revoke/list，须一并落地）
def consume(self, code: str) -> None:
    with self._lock:
        rec = self._codes.get(code)
        if rec is not None:
            rec["revoked"] = True
            self._persist()

def record_failure(self, code: str) -> bool:
    with self._lock:
        rec = self._codes.get(code)
        if rec is None:
            return False
        rec["failed_attempts"] = rec.get("failed_attempts", 0) + 1
        if rec["failed_attempts"] >= 10:
            rec["locked_until"] = time.time() + 300
        self._persist()
        return rec.get("locked_until") is not None

# ④ validate() 开头增加锁定判断
    if rec.get("locked_until") and time.time() < rec["locked_until"]:
        return False
```

> 6→8 位对既有调用点无影响：全局无 `^[0-9]{6}$` 正则约束；调用点仅 `af_auth.py:368`（配对码）与 `:468`（授权码），API 层 `af_api.py:848-853` 直接透传不校验长度。**但须同步**：函数名与 docstring 改 8 位；配对码相关文案（`af_mcp.py:219/228/455/469/475`）若统一口径需一并修订。

#### 2. `src/autoforge/af_mcp.py`

```python
# ① import 行补入（af_mcp.py:31 当前未导入，直接引用会 NameError）
from .af_auth import (AuthCodeStore, PairCodeStore, RateLimiter, RateLimitExceeded,
                      TokenExpired, TokenRegistry)

# ② _t_save 路径 A
if acs.validate(auth_code):
    acs.consume(auth_code)                      # 一次性消耗
    res = svc.submit_pending(store, "af_save", payload, ...)
    applied = svc.approve_pending(store, op_id, reviewer=f"auth_code:{auth_code[:2]}" + "***")
else:
    acs.record_failure(auth_code)               # 失败计数

# ③ serve_mcp() 内实例化（建议模块级 _MCP_RATELIMITER，与 _MCP_AUTH_STORE 风格一致）
_MCP_RATELIMITER = RateLimiter(per_minute=60, window_s=60)

# ④ tools/call 分支内、dispatch 前（只卡 af_save + auth_code 组合，避免误伤合法高频调用）
if params.get("name") == "af_save" and (params.get("arguments") or {}).get("auth_code"):
    try:
        _MCP_RATELIMITER.check("authcode_validate")
    except RateLimitExceeded as exc:
        sys.stdout.write(_error(id_, -32000, str(exc)) + "\n"); sys.stdout.flush(); continue
```

#### 3. 修正失实注释 + 补齐 schema

```python
# af_mcp.py:166-167 改为
# v1.4.0：部署前写操作默认入待批队列，人审后由服务层回放落盘。
# 持有效部署授权码可走快速通道直接部署（人审替代路径；码须高熵 + 一次性消耗 + 限流）。

# af_save inputSchema 显式声明
"auth_code": {"type": "string", "pattern": "^[0-9]{8}$",
              "description": "部署授权码（用户在 WebUI 生成）；一次性消耗，连续 10 次错误锁定 5 分钟"}
```

### 回归测试建议（`tests/test_authcode.py`，全本地无网络）

1. `test_validate_does_not_consume` — 有效码连续 `validate()` 10 次仍 True。**当前通过、修复后应失败**（钉住根因）
2. `test_consume_invalidates` — `consume()` 后 `validate()` 返回 False
3. `test_lockout_after_threshold` — `record_failure()` 10 次后 `validate()` 返回 False
4. `test_lockout_expires` — 篡改 `locked_until` 过期后 `validate()` 恢复 True
5. `test_mcp_rate_limit_on_authcode` — 子进程驱动 `forge mcp`，连发 70 条错误码 `af_save`，断言第 61 条起 `isError=True`；正确码仍成功
6. `test_schema_declares_auth_code` — `tools/list` 断言 `af_save.inputSchema.properties.auth_code` 存在且带 pattern
7. `test_invalid_code_falls_back_to_pending` — 无效码返回含 `pending` 键与「无效或已过期」warning（路径 B 兜底）
