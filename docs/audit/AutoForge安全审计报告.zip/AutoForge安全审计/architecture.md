# Architecture Summary — AutoForge（Phase 1）

## 1. Product, principals, and protected resources

AutoForge 是"Agent 为中心"的智能家居自动化平台：Agent 撰写 JSON IR（或 AF-Spec 文本），经 `forge build` 静态安全闸 → `forge sim` 仿真 → `forge run/watch` 执行，最终下发到 Home Assistant（HA）。人只审阅由 IR 确定性渲染出的自然语言句子。

主体与常规权限：
- **人类用户**（HTTP API / CLI / WebUI）：建、改、审批、下发自动化
- **外部 LLM Agent**（MCP stdio，21 个工具）：读写自动化、查设备、仿真；**被明令禁止调用 approve**（`af_orchestrator.py` 硬护栏）
- **Home Assistant**：被调方，同时是**不可信输入源**（SSE 事件流、状态快照、服务调用响应）
- **运维/部署**：提供 token、secret 文件、容器配置

受保护资源：HA 长期访问令牌、AutoForge API 令牌（read/write/live 三档 scope）、`{store}` 目录下的自动化归档与凭据文件（`.auth/`）、家庭设备控制权（`live` 下发 = 物理世界副作用）、实例持久化数据。

## 2. Comparable baseline

可类比 **Home Assistant 自动化引擎 + Node-RED**：同为家庭自动化执行栈，都接受半结构化配置并驱动设备。HA 生态普遍接受"本地单用户、默认信任内网"的部署假设——因此本仓的宽松默认值应在此基线上校准严重度：**若部署于内网单用户，部分问题的现实影响被显著削弱；若暴露到不可信网络，则放大**。此基线用于校准，不用于否认已证实的边界失效。

## 3. Stack, deployment, and offline limits

Python（要求 3.14，本环境 3.10）、FastAPI + uvicorn、typer CLI、jsonschema、无 ORM。依赖 `homesdk`（**未声明于 `pyproject.toml`，仅以 wheel 存放于 `docker/homesdk/`**）。部署形态：`forge serve`（API）、`forge watch`（常驻订阅 HA SSE）、Docker（`docker/Dockerfile`）。

离线限制：本环境缺 `homesdk`（已用 `--ignore-requires-python` 强装 wheel 绕过）、Python 版本低于要求、`pytest-homeassistant` 无法加载。可执行的是纯 Python 单元测试与内存态 Runtime 复现。

## 4. Entry surfaces and source-to-sink paths

| 入口 | 关键路径 | 汇聚点（sink） |
|---|---|---|
| HTTP API（74 路由） | `af_api.py` | 自动化归档写、`/api/live/run` 真机下发、store 导出 |
| MCP stdio JSON-RPC | `af_mcp.py`（进程内直调服务层） | 与 REST 同源的写能力；`af_save` 持授权码可走直部署快速通道 |
| CLI（`forge *`） | `af_cli.py` + 环境变量 | 文件写、`watch` 子进程派生 |
| **IR / AF-Spec 文本** | `af_ir/models.py#load_graph`、`af_spec.py` | 表达式求值、适配器动作下发 |
| 表达式 operand/fn | `af_ir/expr.py#evaluate` | 纯函数白名单（23 函数），受 `_Budget` 上限约束 |
| HA SSE 事件流 | `af_live.py` / `af_watch.py` | 事件总线 → 实例触发 → 动作下发 |
| 文件系统/目录 | `af_store.py`、`af_persist.py`、`af_catalog.py` | 路径拼接写盘、凭据文件 |

出向 sink：`af_adapters/ha.py`（HA REST，Bearer）、`af_adapters/http.py`（通用 HTTP，主机白名单）、`af_service.py#start_watch`（`subprocess.Popen`，注入 `AUTOFORGE_HA_TOKEN` 到子进程环境）。

## 5. Trust boundaries and strongest source-visible control

1. **API 鉴权** — `af_api.py#requires(scope)` + `af_auth.py#TokenRegistry`：写/live 侧已 fail-closed（无令牌即 403）；**read 侧按源码声明为公开**（三处一致文档），29 条读端点无鉴权依赖
2. **出向主机白名单** — `af_adapters/http.py#is_allowed` + `_WhitelistRedirector`：防 SSRF 与重定向外泄（同族控制 `af_adapters/ha.py#_NoRedirectHandler`）
3. **表达式沙箱** — `af_ir/expr.py`：`MAX_EXPR_DEPTH=32`、`MAX_EXPR_NODES=256`、函数白名单、显式类型声明（禁隐式转换）。设计扎实
4. **静态安全闸** — `af_scanner.py`：26 类检查 + device guard/ACL + 环检测，是"Agent 造错"的主要拦截点
5. **凭据** — `af_secrets.py#load_secret`：secret 文件 > env 回退；常量时间比较（`hmac.compare_digest`）；令牌过期/解析失败 fail-closed
6. **文件系统** — `af_flock.py#FileLock`（advisory）：仅覆盖 GraphStore/PersistStore，**Runtime 本身无跨进程互斥**

## 6. Starting paths

`src/autoforge/af_api.py`、`af_auth.py`、`af_mcp.py`、`af_ir/expr.py`、`af_ir/models.py`、`af_scanner.py`、`af_adapters/ha.py`、`af_adapters/http.py`、`af_store.py`、`af_secrets.py`、`af_live.py`、`af_service.py`、`af_flock.py`、`af_runtime.py`、`pyproject.toml`、`docker/Dockerfile`。

## 7. Prior coverage

**无兼容 prior ledger**，本轮 `prior_status` 全为 `none`。存在一份非本格式的工程审计报告（9 个运行时实证缺陷：实例不回收、canary 不可序列化、总线回调无隔离、emit 无熔断、去重 LRU 污染等），**仅作架构背景与起点提示**，不作为 carried confirmed、不作为覆盖证据。

## 8. Companion selection

选定 `WEB-PROTOCOL-AND-AUTH`（API-key 与浏览器会话）、`AI-AND-LLM`（MCP 与工具/动作）、`RESOURCE-EXHAUSTION-AND-AVAILABILITY`（计算放大与资源累积）、`PROTOCOLS-RPC-AND-MESSAGING`（framing/schema 与 RPC 授权）、`SUPPLY-CHAIN-AND-RELEASE`（依赖与构建输入，针对未声明的 homesdk）、`DESKTOP-MOBILE-AND-LOCAL-IPC`（本地 IPC/特权辅助/本地文件）、`CLOUD-AND-DEPLOYMENT`（配置与密钥生命周期）、`DATA-ISOLATION-AND-LIFECYCLE`（导出/备份面）。

排除 `MEMORY-SAFETY-AND-BINARY`（纯 Python，无原生内存面）与 `CLIENT-SIDE`（`ui/` 前端未纳入本轮 scope）。
