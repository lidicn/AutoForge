# NEEDS-VALIDATION

本轮**没有** `needs_validation` 记录。

按该技能定义，`needs_validation` 表示「一个有源码依据的边界假设被阻塞，缺少某个确切事实」——它**不是**低置信度的 confirmed 漏洞，且**不分配严重度**。本轮三个候选均在本地源码与沙箱内闭合：

| fingerprint | 判定 | 为何不需要外部验证 |
|---|---|---|
| `fp-authcode-bruteforce` | confirmed | 源码路径完整可追溯，沙箱内用真实 `AuthCodeStore` 实测枚举命中（第 245,360 次）与吞吐（1,955,089 次/秒） |
| `fp-api-read-noauth` | rejected | 源码三处一致声明 read scope 为公开，属设计意图确认，不依赖部署事实 |
| `fp-ir-no-size-cap` | rejected | 规模上限缺失与限流覆盖均在源码内可判定，属 hardening note |

---

## 本轮明确的缺口（不是 needs_validation，而是**未覆盖**）

以下为 scoped run 未纳入的 **14 个 `out_of_scope` 单元**。它们**未被审计**，因此**不能**推断为安全。建议按此顺序补全：

| 优先级 | 单元 | 关注点 |
|---|---|---|
| 高 | `pyproject.toml` / `docker/homesdk/*.whl` | `homesdk` 是 `af_executor.py:62` 的顶层硬依赖，却**未声明于 `pyproject.toml`**，wheel 直接躺在 `docker/` 下——供应链面不可审计 |
| 高 | `af_store.py` / `af_persist.py` 路径处理 | 174 处 `open()`/`Path()`/拼接写盘，需查路径穿越与原子写正确性 |
| 中 | `af_adapters/http.py` 主机白名单 | `is_allowed` 与 `_WhitelistRedirector` 是否覆盖所有跳转与协议 |
| 中 | `af_adapters/ha.py` | Bearer 令牌处理、`_NoRedirectHandler`、`_HA_DOMAIN_RE` 是否足以防注入 |
| 中 | `af_secrets.py` / `docker/` 密钥生命周期 | secret 文件 > env 回退链、文件权限、`/run/secrets` 挂载假设 |
| 中 | `af_service.py#start_watch` | `subprocess.Popen` 注入 `AUTOFORGE_HA_TOKEN` 到子进程环境 |
| 中 | `af_flock.py` | advisory 锁仅覆盖 GraphStore/PersistStore，**Runtime 无跨进程互斥** |
| 低 | `af_api.py` CORS | 默认仅 localhost，但 `allow_credentials=True` + `allow_headers=["*"]` 组合值得复核 |
| 低 | `af_live.py` SSE 事件流 | 事件解析与分发健壮性 |
| 低 | `af_runtime.py` 内存容器 | 实例/审计/总线无上限增长（先前工程审计已实证终态实例不回收） |
| 低 | `af_cli.py` | 环境变量与参数输入面 |
| 低 | `af_auth.py#TokenRegistry` | 令牌签发与撤销（本轮已间接覆盖 authenticate 路径） |

---

## 部署相关的事实缺口（非漏洞，需 owner 确认）

以下源码无法判定，需 owner 在实际部署环境确认。**它们不是 needs_validation 记录**，因为没有候选结论依赖它们：

1. **API 实际监听面**：`docker/Dockerfile.api` 启动 `forge serve --host 0.0.0.0 --port 8787`。若部署在不受信任网络，"read 公开"的设计假设不再成立，需给 29 条 read 端点加鉴权
2. **令牌是否配置**：`docker-compose.api.yml` 中 `AUTOFORGE_API_TOKENS` 被注释掉。未配置时 `requires()` 对 write/live 仍 fail-closed 403，但 read 公开
3. **MCP 鉴权是否启用**：未设 `AUTOFORGE_MCP_TOKEN` 时 `serve_mcp` 走原型模式全放行——此时 `af_save` 可直接写入，问题比授权码枚举更严重，**应优先处理**
4. **授权码使用习惯**：若只用短期码（5–30 分钟窗口），`fp-authcode-bruteforce` 的实际收益被压缩；若用长期码且无人值守，high 定级完全成立
