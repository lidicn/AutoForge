# AutoForge 安全审计报告（scoped run）

> 工具：cloudflare/security-audit-skill（六阶段流程）
> 目标：`/data/workspace/AutoForge-main`（zip 快照，无 `.git`，mtime `2026-09-29T22:43`）
> 运行 ID：`af-sec-audit-run-1`　profile：`standard`　状态：`complete`
> 校验器：`coverage-ledger` PASS（22 单元）｜`findings` PASS（3 记录）

---

## ⚠️ 覆盖声明：本轮是**部分覆盖**

审计范围限定为三个面：① `af_api` HTTP 鉴权面 ② `af_mcp` 工具门与 approve 护栏 ③ `af_ir` 表达式求值与 IR 加载。

覆盖账本 22 个单元：**in-scope 8 个（已审）、out_of_scope 14 个（未审，绝不等同于"无问题"）**。

未纳入的面包括：HA/HTTP 适配器与 SSRF 白名单、GraphStore 路径处理与文件写入、secret 生命周期、依赖与供应链（含未声明的 `homesdk`）、`watch` 子进程派生、`af_flock` 跨进程锁、Runtime 内存容器、CLI 输入面、HA SSE 事件流、CORS 配置。

**一次运行不穷尽目标。** 该技能自身的经验数据：单次运行约能发现多轮运行总发现量的**一半**。本轮 3 个候选中 2 个被独立验证者证伪，也从侧面说明单一视角的局限。

---

## 结论概览

| verdict | 数量 | fingerprint |
|---|---|---|
| **confirmed** | 1 | `fp-authcode-bruteforce`（**high**） |
| rejected | 2 | `fp-api-read-noauth`、`fp-ir-no-size-cap` |
| needs_validation | 0 | — |

---

## 确认缺陷：fp-authcode-bruteforce — high

**MCP 面部署授权码为 6 位纯数字且可无限次离线枚举，agent 可绕过人工审批自行部署自动化。**

| 项 | 内容 |
|---|---|
| 低信任主体 | LLM agent（已获本地 MCP stdio 调用权、持有含 `write` scope 令牌） |
| 接受的输入 | `tools/call` 中 `af_save` 的 `arguments.auth_code` |
| 预期控制 | `af_mcp.py:167`「MCP 面绝不注册 approve（agent 不能自批）」；`af_service.py:490`「reviewer 硬编码 human」 |
| 跨越的边界 | 人工审批（人审是本系统中人与 agent 之间的信任边界） |
| 受影响资源 | 生产归档中的自动化 IR（最终可驱动真实设备动作） |
| 已证实结果 | 第 **245,360** 次尝试命中有效授权码；命中后 `af_save` 走路径 A 直接部署，`deployed_via="auth_code"` |

### 路径

```
agent → tools/call af_save（arguments 含 auth_code）
   │  dispatch() 不校验 arguments 与 inputSchema 一致性 → 未声明的 auth_code 可传入
   ▼
_t_save()（af_mcp.py:180）auth_code = args.get("auth_code")
   ▼
AuthCodeStore.validate()（af_auth.py:502）仅判存在/未撤销/未过期，无副作用
   ▼
【路径 A】af_mcp.py:185-191
   svc.submit_pending(...)      # 先入队
   svc.approve_pending(..., reviewer=f"auth_code:XX***")   # 同栈立即批准
   ▼
IR 直接落盘 —— 人工审批被完全跳过
```

### 实测数据（沙箱，2026-09-30）

```
长期码 expires_at = null（永不过期）
validate 连续 5 次 → [True,True,True,True,True]（不消耗）
af_mcp.py 含 RateLimiter: False | 含 limiter: False
validate 吞吐: 1,955,089 次/秒 → 穷举 10^6 约 0.51 秒
实际枚举: 第 245,360 次命中有效码
```

**关键性质**：`AuthCodeStore._load()` 读本地 JSON，**枚举完全在 agent 进程内完成**——无网络往返、不触服务端日志、不被失败计数捕获，服务端完全不可观测。

### 根因

授权码承担「人审替代物」的安全职责，却按「便于人口述」的 **UX 目标**设计：

| 属性 | 实际 | 应有的 |
|---|---|---|
| 熵 | 6 位数字 = 10⁶（`af_auth.py:318`，注释直言「便于口述转告 agent」） | 不可枚举 |
| 生命周期 | 不消耗、无失败计数、无锁定；`kind="long"` 永不过期 | 一次性消耗 + 失败锁定 |
| 通道 | `af_mcp.py` 全文无 `RateLimiter` | 限流 |

`AuthCode` 只有 5 个字段，**没有 `consumed`/`failed_attempts`/`locked_until`**。对比同文件 `PairCode` 明确有 `consumed`——授权码从**数据模型层面**就缺失消耗语义。

### 加重情节

1. **注释即护栏失效**：`af_mcp.py:167` 写「MCP 面绝不注册 approve」，紧随其后的 v1.9.0 授权码路径正是通过 `approve_pending` 在 MCP 面完成了 approve
2. **服务层防护被伪 reviewer 绕过**：`_t_save` 传 `reviewer=f"auth_code:XX***"`，因 `reviewer != submitter` 不触发 `af_service.py:500` 自批检查
3. **schema 未声明却可用**：`af_save` 的 inputSchema 无 `auth_code`，但 `dispatch()` 不校验即透传

### 严重度

| 维度 | 值 | 理由 |
|---|---|---|
| likelihood | medium | 前置条件在设计使用场景下默认成立（agent 本就持 write scope、用户本就会生成授权码）；一旦成立，成本趋零且不可观测 |
| impact | high | 完全击败显式声明的安全控制，设备动作可被 agent 单方面写入生产归档；受静态扫描与所有权隔离约束，非远程未认证执行 |
| **overall** | **high** | 符合锚点「actor fully defeats an explicit security control with real consequences」 |

---

## 两个被证伪的候选（重要）

### fp-api-read-noauth — rejected：**是设计意图，不是漏洞**

表层事实**全部成立**：29 条路由无 `Depends(...)`、`/api/store/export` 返回完整归档 bundle、`_rate_limit_dep` docstring 确写「不鉴权」、已配令牌时读端点匿名仍 200。

但源码三处一致声明 **read 为公开**：
- `af_auth.py:31`「端点分级：`read`（**公开**）/ `write` / `live`」
- `af_api.py:29-31`「read：公开（健康/图表/配置/指标/审计/故障图鉴/store/export/...）」
- `af_api.py:408/456/570/607/618` 逐端点「读端点，不强制鉴权」

且作者已在**同属 read 分级**的其他端点正确应用 `_read = requires("read")`（`af_api.py:509/535/640-644/975-998`）——证明未挂载是选择而非遗漏。鉴权引擎本身工作正常（写端点 fail-closed 403、scope 越权 403）。

> 这条推翻了审计开始前的先验判断。按该技能纪律，「偏离清单」不是漏洞。

**但仍有一条部署建议**（非缺陷）：`docker/Dockerfile.api` 绑定 `0.0.0.0`，`docker-compose.api.yml` 中 `AUTOFORGE_API_TOKENS` 被注释掉。若部署不在受信任内网，"read 公开"的设计假设会被打破——届时应给 29 条端点追加 `dependencies=[Depends(_read)]`。这属**产品策略变更**，不应作为漏洞补丁强推。

### fp-ir-no-size-cap — rejected：**纵深防御缺失，非边界违反**

事实成立：`load_graph` 无规模上限，大图被接受且负载随规模增长（验证者独立实测 N=50000 约 10.1s / RSS 242MB，N=100000 约 19.9s / RSS 485MB）。

判 rejected 的理由：`/api/build` 与 `/api/sim` 继承 app 级 `_rate_limit_dep`，默认 1000 次/分钟按源 IP 限流；本地单进程部署；未证实跨主体损害，符合 `low` 锚点而不达 `medium` 门槛。

**仍建议加固**（hardening note）：`load_graph` 入口加 nodes/edges 长度校验（默认 5000 可配），并给 `SimBody.events` 加 `maxItems`——后者是比图加载更重的放大面。

---

## 未发现问题的面（已审，covered）

| 面 | 结论 |
|---|---|
| 表达式求值 | `MAX_EXPR_DEPTH=32` 强制生效；类型守卫严格——`numeric` 声明遇 `'abc'`/`None`/`True`/`{}` 均报错，禁隐式转换 |
| 函数白名单 | 23 函数白名单；`__import__`/`eval`/`exec`/`open`/`getattr` 全部拒绝 |
| IR schema | 6 类非法结构全部 `IRValidationError` 拒绝 |
| API 限速 | IP+主体双维度、`_MAX_KEYS=10000` 防无界增长、默认不信任 XFF |
| live scope 分级 | 匿名 403、只读令牌访问 live 端点 403「缺少 live 权限」 |
| MCP stdio 通道 | 无网络监听端口，本面无跨主体网络边界 |

**值得肯定**：表达式沙箱与 IR schema 设计质量明显高于同类项目——这是"Agent 造错"的主拦截点，实测确实守住了。

---

## 环境限制

- `homesdk` 需 `--ignore-requires-python` 强装（要求 ≥3.11，沙箱 3.10）
- 目标无 `.git`，**无法给出 commit sha**，快照新鲜度以文件 mtime 为界
- 全部执行为本地源码审查 + 沙箱内 TestClient / 内存复现，**未接触真实 HA、未发起外部请求**
- 无 `needs_validation`：所有结论均在本地闭合

---

## 建议的下一步

1. **优先修 confirmed**：授权码三件套（消耗 + 增大熵 + 失败锁定），并修正两处失实注释——**注释误导比缺陷本身更危险**
2. **若部署不在受信任内网**：把 29 条 read 端点纳入鉴权（产品决策，不是补丁）
3. **加固**：IR 与 `SimBody.events` 加规模上限
4. **补审未纳入的 14 个单元**——尤其 `homesdk` 供应链面（未声明依赖，wheel 直接躺在 `docker/` 下）与 HA 适配器 SSRF 白名单
