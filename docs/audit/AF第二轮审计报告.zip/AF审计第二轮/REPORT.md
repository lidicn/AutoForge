# AutoForge 第二轮审计报告（稳定性 / 功能性）

> 运行 ID：`af-audit-run-2`　工具：cloudflare/security-audit-skill（六阶段）
> 校验器：`coverage-ledger` PASS（24 单元）｜`findings` PASS（4 记录）
> 状态：`complete`

## 口径说明

你要「稳定性 + 功能性 bug」，`security-audit` 只确认**跨越信任边界**的安全发现。双轨：

- `findings.json` — 按技能纪律记 `rejected`（4 条事实成立，均非安全边界违反）
- **`AutoForge第二轮稳定性与功能性缺陷清单.md`** — **你要的交付物**

## 实测环境

- Python 3.10.12（项目要求 3.14）
- 依赖：homesdk（强装 wheel）/ fastapi / typer
- **测试基线：1277 passed / 51 skipped / 0 failed**

> 环境坑：缺 `typer` 时 11 个测试模块**收集失败**（`pytest` 直接中断）。`pyproject` 有声明，本地跑不起来先查这个。

## 核心发现

**`forge watch` 的 SAFE HALT 分支会让 tick 守护线程静默死亡。**

`af_live.py:363` 的 `logger.error(...)` 引用了未定义的 `logger`——模块级无 `logging` 导入，`logger` 只在另一个函数 `read_answer_inbox()` 内绑定，函数作用域不共享。

端到端实测：supervisor 正确进入 SAFE HALT（`halted_reason='escalated after 20 failures'`），但消费侧 `_loop` 随即抛 `NameError`，daemon 线程死亡。

**后果是静默降级而非报错**：主线程 `run_watch` 继续消费 SSE，事件驱动自动化照常工作，但 `tick()` 不再被调用 → 所有时间驱动的 `for` 持续条件与 `wait` 定时器**永不推进**。而 `af_tick_supervisor.py:221` 注释承诺的「外部 watchdog 能重启本线程」**全仓无实现**。

## 测试覆盖缺口

- `test_tick_supervisor.py:79` 测了 SAFE HALT —— 只测 **supervisor 层**（正常）
- `test_af_live.py:219` 测了 `start_ticker` —— 只测**正常路径**

**两侧各测了，接缝没测。** 缺陷恰好长在接缝上。

## 回归确认：第一轮 P0-2 未修复

`af_scheduler.py:343` 仍是 `lease.confirm(instance.id)`，而 `Instance` 只有 `instance_id`。`--persist-dir` 下时间触发仍必崩。一个字符级的改动，但一直没修。

## 一个值得说的结论：AutoForge 确实更干净

我用 5 种系统性扫描各扫全仓：

| 维度 | 结果 |
|---|---|
| 未定义名（symtable 作用域分析，92 文件） | 仅 `logger` **1 处** |
| `self.X` 只读未写（AST + 基类链解析） | **0 处** |
| 除零 / 空序列 | 5 处候选**全部有守卫** |
| 进程级缓存无界 | **0 处**（有 TTL / 有界 key / 有锁） |
| 锁泄漏 | **0 处** |
| 异步任务（`create_task`） | **0 处**（并发模型是 threading） |

对比 memory-agent 第二轮：同样方法挖出 4 个 NameError + 7 处 `create_task` 问题；AutoForge 只有 1 个。

这让第一轮「AutoForge 内核质量明显高于同类项目」的判断再次得到印证。**测试全绿不是运气。**

## 建议优先级

1. 修 `logger` + 给 `_loop` 加 try/except 兜底
2. 修第一轮 P0-2 `instance.id`
3. 补 watchdog，或至少把 tick 线程死亡做成可见事件
4. 补接缝测试：SAFE HALT × `start_ticker` 消费侧组合用例

## 未覆盖

24 单元中 14 个 `out_of_scope`：HTTP 鉴权、MCP 授权码、表达式沙箱、`af_store`、`af_persist`、`af_executor` canary、`af_bus`、`af_instance` 终态回收、`af_orchestrator`、`af_scanner`、HA 适配器、`af_secrets`、CLI 输入面、`homesdk` 供应链。
