# AutoForge 第二轮审计 · 稳定性与功能性缺陷清单

> 运行 ID：`af-audit-run-2`　工具：cloudflare/security-audit-skill（六阶段）
> 目标：`lidicn/AutoForge`（zip 快照，mtime `2026-09-29T22:43`）
> 校验器：`coverage-ledger` PASS（24 单元）｜`findings` PASS（4 记录）
> 实测环境：Python 3.10.12｜依赖含 homesdk / fastapi / typer｜**测试基线 1277 passed / 51 skipped / 0 failed**

---

## 一句话结论

**找到 1 个高危缺陷：`forge watch` 的 SAFE HALT 分支会让 tick 守护线程静默死亡。**

后果不是"报错"，是**静默降级**——事件驱动的自动化照常工作，但所有时间驱动的 `for` 持续条件与 `wait` 定时器**永不推进**，且无任何可见信号。

另外回归确认：**第一轮的 P0-2（`instance.id`）至今未修复。**

---

## 缺陷 1（高）· `SAFE HALT` 分支引用未定义 `logger`，tick 线程静默死亡

**位置**：`src/autoforge/af_live.py:363`（函数 `start_ticker` 内嵌的 `_loop`）

### 根因

模块级导入**没有 `logging`**：

```python
# af_live.py 模块级（L20-30）
import json, threading, time, urllib.request
from pathlib import Path
from typing import Any, Callable, ...
```

而 `logger` 只在**另一个函数**里绑定：

```python
# L373-383  read_answer_inbox()
def read_answer_inbox(runtime, inbox_dir=None):
    import hashlib
    import hmac
    import logging          # ← 函数内导入
    import os
    ...
    logger = logging.getLogger("autoforge.live")   # ← 函数内绑定
```

但 L363 用它：

```python
# L356-368  start_ticker() 内嵌 _loop()
def _loop() -> None:
    while not stop.is_set():
        if stop.wait(interval_s): break
        outcome = supervisor.run_once(fn)
        if outcome.status.value == "halted":
            logger.error("tick SAFE HALTED: %s", supervisor.health().halted_reason)  # ← L363 NameError
            break
        ...
t = threading.Thread(target=_loop, daemon=True)
```

**函数内 `import` 的作用域不跨函数**。L363 与 L383 分属 `_loop` 与 `read_answer_inbox`，所以 `logger` 未绑定。

### 端到端实测

构造 `runtime.tick` 持续抛异常，逼出 SAFE HALT：

```
tick FaultClass.TRANSIENT ... （×20）
SAFE HALT: RuntimeError('模拟致命 tick 故障')

supervisor 是否 halted: True
halted_reason: 'escalated after 20 failures'
tick 线程是否存活: False   ← 已死
线程死亡原因: NameError: name 'logger' is not defined
```

**supervisor 本身工作完全正常**——它在第 20 次失败后正确进入了 SAFE HALT 并给出了原因。崩溃发生在**消费方**。

### 为什么后果比"报错"严重

1. **线程是 `daemon=True`** —— 死亡不影响主进程，process 继续跑
2. **主线程 `run_watch` 继续消费 SSE 事件** —— 事件驱动的自动化照常触发，**看起来一切正常**
3. **但 `tick()` 再也不会被调用** —— 时间驱动的 `for` 持续条件、`wait` 节点定时器**永不推进**
4. **设计文档声称的 watchdog 不存在** —— `af_tick_supervisor.py:221` 写着「供 /health 与外部 watchdog 调用（watchdog 在主线程，**能重启本线程**）」，但全仓检索**没有 watchdog 实现**

合起来就是：系统进入一个**表面上正常、实际上时间类自动化全部停摆**的状态，且无人知晓。

`forge watch` 正是通过 `af_cli.py:615` 调用 `start_ticker`——这是生产常驻路径。

### 测试覆盖缺口（为什么它活到今天）

- `test_tick_supervisor.py:79` 测了 SAFE HALT —— 但只测 **supervisor 层**（工作正常）
- `test_af_live.py:219` 测了 `start_ticker` —— 但只测**正常路径**（tick 到 stop）

**两侧各测了，接缝没测。** 缺陷恰好长在接缝上。

### 修复

```python
# 方案 A（最小）：af_live.py 模块级补导入
import logging
logger = logging.getLogger("autoforge.live")
# 然后删除 read_answer_inbox 内的 import logging 与 logger = ...

# 方案 B（建议，同时修韧性）：给 _loop 加兜底
def _loop() -> None:
    while not stop.is_set():
        if stop.wait(interval_s): break
        try:
            outcome = supervisor.run_once(fn)
            if outcome.status.value == "halted":
                logger.error("tick SAFE HALTED: %s", supervisor.health().halted_reason)
                break
            _write_asks()
            read_answer_inbox(runtime, inbox_dir=inbox)
        except Exception:
            logger.exception("ticker 循环异常（继续下一轮）")
```

方案 B 更彻底：`_loop` 目前**完全没有 try/except**，任何未捕获异常都会杀死线程。

### 回归测试

```python
def test_start_ticker_safe_halt_does_not_kill_thread():
    # tick 持续抛异常直至 SAFE HALT
    # 断言：线程仍存活（走了 break 而非崩溃）且 halted_reason 被记录
```

---

## 缺陷 2（中）· tick 线程无异常兜底，声称的 watchdog 不存在

与缺陷 1 同源但独立成立，单列以便跟踪：

- `_loop()` 整体无 `try/except`
- `daemon=True`：线程死亡不冒泡到主进程
- `af_tick_supervisor.py:221` 注释承诺的 watchdog **全仓无实现**
- `/api/health` 虽暴露 `tick_health`（`af_service.py:183`），但**只报告不重启**

即使修掉 `logger`，任何其它未捕获异常仍会走同一条静默死亡路径。

---

## 回归确认：第一轮 P0-2 仍未修复

`src/autoforge/af_scheduler.py:343` 依然写作：

```python
lease.confirm(instance.id)
```

而 `Instance` 类**只有 `instance_id`**（`af_instance.py:138` 的 `@property`），**没有 `id`**。

实测 `Instance` 公开属性清单确认：含 `instance_id`、不含 `id`。

第一轮已实证：这导致 `--persist-dir` 形态下时间触发**必然** `AttributeError`。当前快照**未修复**。

---

## 本轮证伪的排查（诚实记录）

这轮我用 4 种系统性扫描各扫了全仓，**结论是 AutoForge 在这些维度相当干净**——这本身是个有价值的结论：

| 扫描维度 | 方法 | 结果 |
|---|---|---|
| 未定义名 | symtable 作用域分析（92 文件） | 除 `__class__`/`__file__` 隐式名外，**仅 `logger` 1 处真未绑定** |
| `self.X` 只读未写 | AST + 基类链解析 | **0 处**（`af_vhass/device_sm.py` 的 27 处初筛候选全部继承自 `DeviceSM`，属误报） |
| 除零 / 空序列 | 分母扫描 + 实测 | **5 处候选全部有守卫**（`avg()` 抛 `ExprError`、`total_w or 1.0`、`not model.events` 判空） |
| 进程级缓存无界 | 模块级容器 + 淘汰逻辑 | **0 处**（`_SESSIONS` 有 TTL、`_telemetry` 有 `_PRUNE_EVERY`、其余 key 空间受路径约束且带锁） |
| 锁泄漏 | `.acquire()` vs `with` | **0 处**（43 处 `with _lock`，唯一裸 `acquire` 在 `FileLock.__enter__` 内由 `__exit__` 保证） |
| 异步任务 | `create_task` 全仓检索 | **0 处**（并发模型是 threading，与 memory-agent 不构成同类问题） |

**这是 AutoForge 与 memory-agent 的显著质量差异**：memory-agent 第二轮同样的扫描挖出 4 个 NameError + 7 处 create_task 问题；AutoForge 同样方法只挖出 1 个。第一轮对 AutoForge「内核质量明显高于同类」的判断在此得到再次印证。

---

## 建议优先级

1. **修缺陷 1**（`logger` + 给 `_loop` 加兜底）—— 一行导入 + 一个 try/except
2. **修第一轮 P0-2**（`instance.id` → `instance.instance_id`）—— 一个字符级改动，但它是 `--persist-dir` 下时间触发的必崩点
3. **补 watchdog 或至少把 tick 线程死亡做成可见事件**——否则这类静默失效还会再发生
4. **补接缝测试**：supervisor SAFE HALT × `start_ticker` 消费侧的组合用例

---

## 未覆盖声明

24 个单元中 **14 个 `out_of_scope` 未审**：HTTP 鉴权、MCP 授权码、表达式沙箱、`af_store` 路径与原子写、`af_persist` 租约、`af_executor` canary、`af_bus` 去重熔断、`af_instance` 终态回收、`af_orchestrator`、`af_scanner`、HA 适配器、`af_secrets`、CLI 输入面、`homesdk` 供应链。

**本轮聚焦稳定性/功能性，不代表安全面已审计。**
