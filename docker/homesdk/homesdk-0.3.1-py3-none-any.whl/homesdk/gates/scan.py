"""五条门禁的 AST 扫描。

规则集（与工单口径一一对应）：

| rule | 判什么 | 默认级别 |
|---|---|---|
| `except-pass-bare` | 裸 `except:` + 空体 | error（任何文件） |
| `except-pass-broad` | `except Exception/BaseException:` + 空体 | 关键模块 error，其余 warn |
| `fake-ok-const` | 返回/构造的字面量 dict 里 `"ok"/"success"/"passed": True` | 写入路径 error，其余 warn |
| `swallow-and-claim-ok` | **同一函数内**既有空体 except 又有 `ok←True` | error（任何文件） |
| `local-consent-table` | 仓内自行定义同意词表（`_YES_WORDS` 等） | error，需配置显式开启 |
| `inline-consent-list` | 内联词表 `any(w in text for w in [ … ])`（butler P0-12 的形状） | error，需配置显式开启 |
| `builtin-credential-const` | 具名凭据常量被赋了字面量（`TVPILOT_DEVICE_TOKEN = "…"`) | error，需配置显式开启（G4） |
| `env-default-credential` | `getenv("…_PASSWORD", "兜底值")`——缺凭据时自带的第二个参数 | error，需配置显式开启（G4） |
| `empty-credential-allows` | `if not token: return True`——空凭据直接放行（fail-open） | error，需配置显式开启（G4） |
| `http-no-timeout` | `requests.get/post/...`、`urlopen(...)` 没传 `timeout` | error，需配置显式开启（G5） |
| `http-timeout-unbounded` | `timeout=0` / `timeout=None`——挂死到底，等于没设 | error，需配置显式开启（G5） |

`swallow-and-claim-ok` 是本套门禁存在的理由：它正是「失败被咽下 + 对外宣称成功」的机器可读形状——
autoflow 的 `rolled_back: (snap is not None)`、AutoForge 的 `simulate().ok` 恒真、MA 的 `except: pass` 三例，
都落在这条规则上。

G4/G5 治的是同一类病的另一半：**凭据和超时都是「默认值」出事的地方**。

G4 有现网实证：`if self.username:` 才设凭据、随后无条件 `connect`（DeskPilot
`modules/mqtt_client.py:142`→`:151`）、`os.environ.get("MQTT_PASS") or None` 之后照样连
（TVPilot `tvpilot_server.py:159`）、拿空串当凭据送出（butler `bus/mqtt_client.py:35`）——
三处都是「缺凭据 = 匿名放行」，而且**没有任何一条会报错**。

G5 没有现网实证，这一点写死在这里：本轮用这把尺扫七个仓的主源码，
Python 侧 102 处 `库名.方法()` 形态的 HTTP 调用**全部带 timeout**，TV_CAM Java 侧 10 处
`openConnection()` 也全部配了 `setConnectTimeout/setReadTimeout`（数字与命令见 `doc/生态链调用边表.md`）。
命中集中在 `tmp_*` / `test_*` / `_legacy` / `.venv*/site-packages`。
所以 G5 的定位是**防回归 + 零开闸成本**：今天三家一挂就是绿的，而它守住的是
「下次有人写 `requests.get(url)` 时不知道生态中位数是 5s」这一刻意失忆。
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path

from .config import CONSENT_TABLES, GateConfig, matches_glob
from ..consent import CONSENT_VOCAB

OK_KEYS: frozenset[str] = frozenset({"ok", "success", "passed"})
BROAD_NAMES: frozenset[str] = frozenset({"Exception", "BaseException"})
RULE_ERROR: str = "error"
RULE_WARN: str = "warn"

#: 名字**末段**命中即视为「这个变量装的是凭据值」。只看末段是有意的：
#: `PASSWORD_ENV_KEY` 装的是键名，不是凭据，把它判成违规会让人把规则关掉。
CREDENTIAL_TAIL_WORDS: frozenset[str] = frozenset(
    {"TOKEN", "PASSWORD", "PASSWD", "PASS", "SECRET", "APIKEY", "CREDENTIAL", "CREDENTIALS"}
)
#: 两段式凭据名（`SECRET_KEY` / `API_KEY` / `ACCESS_KEY`）。
CREDENTIAL_TAIL_PAIRS: frozenset[tuple[str, str]] = frozenset(
    {("SECRET", "KEY"), ("API", "KEY"), ("ACCESS", "KEY"), ("BEARER", "TOKEN")}
)
#: 枚举成员装的是状态码（`NO_CREDENTIALS = "no-credentials"`），不是凭据，整类跳过。
ENUM_BASES: frozenset[str] = frozenset({"Enum", "IntEnum", "StrEnum", "Flag", "IntFlag", "ReprEnum"})
#: 「放行」的字面形状：`return True` / `return "ok"` / `return AuthCheck.OK`。
ALLOW_WORDS: frozenset[str] = frozenset({"OK", "ALLOW", "ALLOWED", "GRANTED", "PASS", "TRUE"})

#: 只认「库名.方法」这种点号形态。裸 `get(` 不认——那是 `dict.get`，会把每个仓都刷红。
HTTP_CLIENT_ROOTS: frozenset[str] = frozenset({"requests", "httpx", "aiohttp", "urllib", "urllib3", "tornado"})
HTTP_METHOD_NAMES: frozenset[str] = frozenset(
    {"get", "post", "put", "patch", "delete", "head", "options", "request", "fetch", "execute", "send"}
)
#: 不带库名也认的裸函数（`urlopen` 从 `urllib.request` import 过来就是这个名字）。
HTTP_FUNC_NAMES: frozenset[str] = frozenset({"urlopen", "urlretrieve"})


@dataclass(frozen=True)
class Violation:
    """一条违规。`fingerprint` 刻意不含行号——改一行不该让基线失效。

    `tag` 用来区分「同一函数里的两处同类违规」（如模块级 `_YES_WORDS` 与 `_NO_WORDS`）：
    不带 tag 时它们指纹相同，基线一行就能同时放过两条，净减少也就没人看得见了。
    """

    rule: str
    rel_path: str
    line: int
    qualname: str
    message: str
    level: str
    tag: str = ""

    @property
    def fingerprint(self) -> str:
        base = f"{self.rel_path}#{self.rule}#{self.qualname}"
        return f"{base}#{self.tag}" if self.tag else base

    def render(self) -> str:
        loc = f"{self.rel_path}:{self.line}"
        return f"{self.level.upper():5} {self.rule:24} {loc:60} {self.qualname}  {self.message}"


def _is_trivial_suppression(handler: ast.ExceptHandler) -> bool:
    """ except 体只有 `pass`（或字符串字面量 + pass）。任何真实处理都不算。"""
    body = [s for s in handler.body if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant) and isinstance(s.value.value, str))]
    return bool(body) and all(isinstance(s, ast.Pass) for s in body)


def _handler_kind(handler: ast.ExceptHandler) -> str | None:
    if handler.type is None:
        return "bare"
    node = handler.type
    names = node.elts if isinstance(node, ast.Tuple) else [node]
    for item in names:
        if isinstance(item, ast.Name) and item.id in BROAD_NAMES:
            return "broad"
        if isinstance(item, ast.Attribute) and item.attr in BROAD_NAMES:
            return "broad"
    return None


class _Visitor(ast.NodeVisitor):
    def __init__(self, rel_path: str, config: GateConfig) -> None:
        self.rel_path = rel_path
        self.config = config
        self.scope: list[str] = []
        self.violations: list[Violation] = []
        #: qualname -> 是否出现过空体 except（给 swallow-and-claim-ok 用）
        self.suppressed: set[str] = set()
        self.is_critical = matches_glob(rel_path, config.critical_globs)
        self.is_write_path = matches_glob(rel_path, config.write_path_globs)
        self.in_enum = False

    # ── 作用域 ────────────────────────────────────────────────────────
    def _visit_scoped(self, node: ast.AST, name: str) -> None:
        self.scope.append(name)
        self.generic_visit(node)
        self.scope.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._visit_scoped(node, node.name)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._visit_scoped(node, node.name)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        outer = self.in_enum
        self.in_enum = outer or any(_dotted(base) in ENUM_BASES or _dotted(base).endswith(".Enum") for base in node.bases)
        self._visit_scoped(node, node.name)
        self.in_enum = outer

    @property
    def qualname(self) -> str:
        return ".".join(self.scope) or "<module>"

    # ── 规则① except 咽下 ─────────────────────────────────────────────
    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        kind = _handler_kind(node)
        if kind and _is_trivial_suppression(node):
            if kind == "bare":
                rule, level, msg = "except-pass-bare", RULE_ERROR, "裸 except 咽下一切异常且不做处理"
            elif self.is_critical:
                rule, level, msg = "except-pass-broad", RULE_ERROR, "关键模块（鉴权/回滚/闸门/快照）咽下 Exception"
            else:
                rule, level, msg = "except-pass-broad", RULE_WARN, "咽下 Exception 且不做处理"
            self.violations.append(Violation(rule, self.rel_path, node.lineno, self.qualname, msg, level))
            self.suppressed.add(".".join(self.scope))
        self.generic_visit(node)

    # ── 规则② 假成功字面量 ────────────────────────────────────────────
    def visit_Dict(self, node: ast.Dict) -> None:
        for key, value in zip(node.keys, node.values, strict=False):
            if not (isinstance(key, ast.Constant) and key.value in OK_KEYS):
                continue
            if isinstance(value, ast.Constant) and value.value is True:
                level = RULE_ERROR if self.is_write_path else RULE_WARN
                where = ".".join(self.scope)
                if where in self.suppressed or any(s and where.startswith(s) for s in self.suppressed):
                    self.violations.append(
                        Violation(
                            "swallow-and-claim-ok", self.rel_path, node.lineno, self.qualname,
                            f"同一函数内既咽下异常又返回 {key.value}=True —— 谎报成功", RULE_ERROR,
                        )
                    )
                else:
                    self.violations.append(
                        Violation(
                            "fake-ok-const", self.rel_path, node.lineno, self.qualname,
                            f"字面量 {key.value}=True，不来自任何实际校验", level,
                        )
                    )
        self.generic_visit(node)

    # ── 规则③（G3 加严）同意词表只准有一处 ────────────────────────────
    def visit_Assign(self, node: ast.Assign) -> None:
        if self.config.forbid_local_consent_tables:
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in CONSENT_TABLES:
                    self.violations.append(
                        Violation(
                            "local-consent-table", self.rel_path, node.lineno, self.qualname,
                            f"仓内定义 `{target.id}` —— 同意判定必须来自 homesdk.consent", RULE_ERROR,
                            tag=target.id,
                        )
                    )
        for target in node.targets:
            self._check_credential_const(target, node.value)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            self._check_credential_const(node.target, node.value)
        self.generic_visit(node)

    def _check_credential_const(self, target: ast.AST, value: ast.AST) -> None:
        """规则④（G4）：具名凭据不许在代码里给字面量。

        只报**名字末段**是凭据词的（`TVPILOT_DEVICE_TOKEN`），并跳过枚举成员——
        `NO_CREDENTIALS = "no-credentials"` 装的是状态码，把它判红会让人直接关掉整条规则。
        消息里**只给长度不给值**：门禁输出会被贴进工单和聊天记录。
        """
        if not self.config.forbid_builtin_credentials or self.in_enum:
            return
        if not (isinstance(target, ast.Name) and _is_credential_name(target.id)):
            return
        secret = _literal_secret(value)
        if secret is None:
            return
        self.violations.append(
            Violation(
                "builtin-credential-const", self.rel_path, target.lineno, self.qualname,
                f"`{target.id}` 被赋了内置字面量（长度 {len(secret)}）—— 凭据只能来自 env",
                RULE_ERROR, tag=target.id,
            )
        )

    def _check_env_default(self, call: ast.Call) -> None:
        """规则④b（G4）：`getenv("…_PASSWORD", "兜底值")` 的第二个参数就是内置凭据。

        这条比具名常量更隐蔽：仓里 grep 不到「赋值给 TOKEN 的字面量」，
        但缺凭据时会拿到一个非空默认值，然后带着它去连服务。
        """
        if not self.config.forbid_builtin_credentials:
            return
        if _dotted(call.func).rsplit(".", 1)[-1] not in {"getenv", "get"}:
            return
        if len(call.args) < 2 or not isinstance(call.args[0], ast.Constant):
            return
        key = call.args[0].value
        if not (isinstance(key, str) and _is_credential_name(key)):
            return
        secret = _literal_secret(call.args[1])
        if secret is None:
            return
        self.violations.append(
            Violation(
                "env-default-credential", self.rel_path, call.lineno, self.qualname,
                f"凭据键 `{key}` 带了内置兜底值（长度 {len(secret)}）—— 缺凭据必须失败，不许兜底",
                RULE_ERROR, tag=key,
            )
        )

    def visit_If(self, node: ast.If) -> None:
        """规则④c（G4）：空凭据直接放行 —— `if not token: return True`。

        这是 G4 的 fail-open 半边，也是现网真正付出的代价：
        凭据没配 → 判定为「通过」→ 门禁形同虚设，而且**没人会报错**。
        """
        if self.config.forbid_builtin_credentials:
            names = _falsy_test_names(node.test)
            hit = next((n for n in names if _is_credential_name(n)), None)
            if hit and any(_grants_access(s) for stmt in node.body for s in ast.walk(stmt)):
                self.violations.append(
                    Violation(
                        "empty-credential-allows", self.rel_path, node.lineno, self.qualname,
                        f"`{hit}` 为空时直接放行 —— 鉴权默认值必须是「不通过」", RULE_ERROR, tag=hit,
                    )
                )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        """内联词表：`any(w in text for w in ["确认","好的",…])`。

        doubao-butler 的 P0-12 就是这个形状——**没有命名常量，所以 `visit_Assign` 抓不到**。
        G3 只查具名词表的话，一家可以把词表全改成内联字面量来「合规」。
        """
        if self.config.forbid_local_consent_tables and isinstance(node.func, ast.Name) and node.func.id in {"any", "all"}:
            hits = _inline_word_list(node)
            if hits:
                self.violations.append(
                    Violation(
                        "inline-consent-list", self.rel_path, node.lineno, self.qualname,
                        f"内联同意词表（命中 {len(hits)} 个判定词：{'、'.join(hits[:4])}）"
                        " —— 同意/取消判定必须来自 homesdk.consent",
                        RULE_ERROR,
                        tag="、".join(hits[:3]),
                    )
                )
        if self.config.require_http_timeout:
            self._check_http_timeout(node)
        self._check_env_default(node)
        self.generic_visit(node)

    def _check_http_timeout(self, node: ast.Call) -> None:
        """规则⑤（G5）：HTTP 调用必须显式带上非零 timeout。

        只认 `库名.方法()` 和 `urlopen()` 两种形态。裸 `get(` 一律不认——
        那是 `dict.get`，认了就是把每个仓刷红，规则活不过第一天。
        已知盲区：`from requests import get` 之后的裸 `get(url)`，以及
        timeout 由变量/配置传入时无法判定字面值（只判 `0` / `None` 两种字面量）。
        """
        callee = _dotted(node.func)
        if not callee:
            return
        parts = callee.split(".")
        is_http_call = parts[-1] in HTTP_FUNC_NAMES or (
            len(parts) >= 2 and parts[0] in HTTP_CLIENT_ROOTS and parts[-1] in HTTP_METHOD_NAMES
        )
        if not is_http_call:
            return
        kw = next((k for k in node.keywords if k.arg == "timeout"), None)
        if kw is None:
            self.violations.append(
                Violation(
                    "http-no-timeout", self.rel_path, node.lineno, self.qualname,
                    f"`{callee}(...)` 没有 timeout —— 对端挂住时整条链路跟着挂住", RULE_ERROR, tag=callee,
                )
            )
            return
        value = kw.value
        limit = _numeric_literal(value)
        is_none = isinstance(value, ast.Constant) and value.value is None
        if is_none or (limit is not None and limit <= 0):
            self.violations.append(
                Violation(
                    "http-timeout-unbounded", self.rel_path, node.lineno, self.qualname,
                    f"`{callee}(...)` 的 timeout={ast.unparse(value)} 等于不设 —— 会挂死到底", RULE_ERROR, tag=callee,
                )
            )


def _inline_word_list(node: ast.Call) -> list[str]:
    """`any(x in <文本> for x in [字面量…] )` → 返回字面量表，否则 []。

    刻意保守：≥4 个、每个 ≤6 字符的字符串字面量，左操作数必须是推导变量，
    右操作数必须引用一个名字（真实文本）。普通业务枚举（`if ext in (".py",".md")`）不报。
    """
    if not node.args:
        return []
    arg = node.args[0]
    if not (isinstance(arg, ast.GeneratorExp) and arg.generators):
        return []
    gen = arg.generators[0]
    if not isinstance(gen.target, ast.Name) or not isinstance(gen.iter, (ast.List, ast.Tuple)):
        return []
    words = [e.value for e in gen.iter.elts if isinstance(e, ast.Constant) and isinstance(e.value, str)]
    if len(words) != len(gen.iter.elts) or not all(0 < len(w) <= 6 for w in words):
        return []
    elt = arg.elt
    if not (isinstance(elt, ast.Compare) and len(elt.ops) == 1 and isinstance(elt.ops[0], ast.In)):
        return []
    if not (isinstance(elt.left, ast.Name) and elt.left.id == gen.target.id):
        return []
    if not _ref_names(elt.comparators[0]):
        return []
    # 只抓「同意/否决」词汇，不抓设备指令词表：后者不是本规则要治的病。
    # 门槛定在 2 个精确命中的词汇——`["好","行"]` 这种短表也逃不掉。
    hits = [w for w in words if w in CONSENT_VOCAB]
    return hits if len(hits) >= 2 else []


def _ref_names(node: ast.AST) -> set[str]:
    return {n.id for n in ast.walk(node) if isinstance(n, ast.Name)}


# ── G4/G5 的形状判定 ──────────────────────────────────────────────────
def _numeric_literal(node: ast.AST) -> float | int | None:
    """字面量数值，含 `-1` 这种 `UnaryOp(USub, Constant)` 写法；不是字面量则 None。"""
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        inner = _numeric_literal(node.operand)
        return -inner if inner is not None else None
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return node.value
    return None


def _dotted(node: ast.AST) -> str:
    """`a.b.c` → `"a.b.c"`；不是纯点号链（如 `f()[0].get`）则给空串。"""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _dotted(node.value)
        return f"{base}.{node.attr}" if base else ""
    return ""


def _is_credential_name(name: str) -> bool:
    """名字**末段**是不是凭据词。`BUTLER_WEB_PASSWORD` ✓，`PASSWORD_ENV_KEY` ✗（那是键名）。"""
    segs = [s for s in name.upper().replace("-", "_").split("_") if s]
    if not segs:
        return False
    if segs[-1] in CREDENTIAL_TAIL_WORDS:
        return True
    return len(segs) >= 2 and tuple(segs[-2:]) in CREDENTIAL_TAIL_PAIRS


def _literal_secret(node: ast.AST) -> str | None:
    """字面量里的第一个非空字符串（含字面量表元素）；没有则 None。

    Dict 刻意不钻：`LEGACY_TOKEN_KEYS = {"butler": ("BUTLER_TOKEN", …)}` 的值是**键名表**，
    正是本 SDK 推荐的做法，判红等于打自己。
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, bytes)):
        raw = node.value if isinstance(node.value, str) else node.value.decode("utf-8", "replace")
        return raw or None
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        for elt in node.elts:
            found = _literal_secret(elt)
            if found:
                return found
    return None


def _falsy_test_names(test: ast.AST) -> set[str]:
    """`if not token:` / `if not token or …` 里被否定的那些名字。"""
    out: set[str] = set()
    for node in ast.walk(test):
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            if isinstance(node.operand, ast.Name):
                out.add(node.operand.id)
    return out


def _grants_access(stmt: ast.AST) -> bool:
    """这个语句是不是「放行」：`return True` / `return "ok"` / `return X.OK`。"""
    if not (isinstance(stmt, ast.Return) and stmt.value is not None):
        return False
    value = stmt.value
    if isinstance(value, ast.Constant):
        if value.value is True:
            return True
        return isinstance(value.value, str) and bool(value.value.strip())
    if isinstance(value, ast.Name):
        return value.id.upper() in ALLOW_WORDS
    if isinstance(value, ast.Attribute):
        return value.attr.upper() in ALLOW_WORDS
    return False


def _suppress_scopes(tree: ast.AST) -> set[str]:
    """先扫一遍，收集「出现过空体 except」的作用域。

    必须两趟：单趟按源码序走，`return {"ok": True}` 写在 except 之前的函数就漏判了。
    """
    parents = {id(child): parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}
    out: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler) and _handler_kind(node) and _is_trivial_suppression(node):
            chain: list[str] = []
            ancestor = parents.get(id(node))
            while ancestor is not None:
                if isinstance(ancestor, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef):
                    chain.append(ancestor.name)
                ancestor = parents.get(id(ancestor))
            out.add(".".join(reversed(chain)))
    return out


def scan_source(rel_path: str, source: str, config: GateConfig) -> list[Violation]:
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:  # 语法错本身就让 import 冒烟红，这里只报一条
        return [Violation("syntax-error", rel_path, exc.lineno or 0, "<module>", str(exc.text or "").strip(), RULE_ERROR)]
    visitor = _Visitor(rel_path, config)
    visitor.suppressed |= _suppress_scopes(tree)
    visitor.visit(tree)
    return visitor.violations


def scan_file(path: Path, repo_root: Path, config: GateConfig) -> list[Violation]:
    rel = path.relative_to(repo_root).as_posix()
    # utf-8-sig：Python 的导入器会自行吞掉 BOM，`ast.parse` 不会。
    # 实测 doubao-butler 的 `roles/store.py`、`tts/edge_tts.py` 带 BOM——用 utf-8 读会报出两条假 syntax-error。
    return scan_source(rel, path.read_text(encoding="utf-8-sig", errors="replace"), config)
