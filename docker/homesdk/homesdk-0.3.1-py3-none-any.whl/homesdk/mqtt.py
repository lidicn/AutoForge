"""统一的 MQTT 客户端构造：paho 可选依赖、QoS 默认 1、缺凭据即拒。

本模块**只配置、不连接**：`get_client` 返回一个配好的 Client，
`connect` 由调用方自己发起。这样测试不需要 broker、不需要网络、不需要设备，
而生态里真正需要的东西（paho 版本探测、QoS 一致、凭据策略）也确实在这里收完了。

paho-mqtt 是重依赖，homesdk 不强制安装：

    try: import paho.mqtt.client as mqtt
    except ImportError: mqtt = None

没装时 import 本模块照常成功，调用 `get_client` 才抛 `MqttUnavailable`。

三条策略来自取证现网的真实分裂，不是偏好：

1. **paho API 三形状**。butler `bus/mqtt_client.py:30` 与 DeskPilot
   `mqtt_client.py:138` 用 `Client(callback_api_version=VERSION2, ...)`；
   TVPilot `:2720` 用裸 `Client()`（paho 1.x）；memory-agent `mqtt_bridge.py:71`
   用 `Client(VERSION1, ...)` 并靠 `AttributeError` 回退。不运行时探测就装不上其中一家。
2. **QoS**。butler 全 1、TVPilot 订阅 `face` 用 0、DeskPilot 发布默认 0、
   memory-agent 统一 1 但文档里留着「旧连接残留 qos=0」。默认给 1。
3. **空凭据**。DeskPilot `mqtt_client.py:142`（`if self.username:` 才 `username_pw_set`，
   随后 :151 无条件 `connect`）与 TV `MqttManager.java:143` 都是
   「username 为空就不设置，照样连上」= 匿名接入 broker。一旦拿到这套凭据
   就能发 `butler/trigger/*`、`tv/livingroom/cmd/*`、`deskpilot/cmd/#` 指挥全屋，
   所以这里默认**拒绝**，要匿名连得显式传 `allow_anonymous=True`。

broker 地址同样不内置：`MQTT_HOST` 缺失即抛，与 `homesdk.http` 的「库内零私网地址」同一条规矩。
"""

from __future__ import annotations

import json as _json
import os
from typing import Any, Final

from homesdk.config import MissingEnv, first_env, get_env_int, require_env
from homesdk.http import peer_name

try:  # 可选依赖：没装 paho 时 homesdk 其余模块必须照常可用
    import paho.mqtt.client as _paho
except ImportError:
    _paho = None

#: 生态统一 QoS。见模块 docstring 第 2 条。
QOS: Final = 1

#: 未显式指定端口时的 broker 端口（协议标准值，不是私网地址）。
DEFAULT_PORT: Final = 1883

#: 自动重连退避区间，交给 paho 自己跑（memory-agent `mqtt_bridge.py:79` 用的就是这对值）。
RECONNECT_MIN: Final = 5
RECONNECT_MAX: Final = 60


class MqttUnavailable(RuntimeError):
    """paho-mqtt 未安装。装它是对**调用方**的要求，不是对 homesdk 的。"""


class MqttCredentialsMissing(MissingEnv):
    """凭据不成套且未显式允许匿名。"""


def paho_available() -> bool:
    """当前环境能否用 `get_client`。"""
    return _paho is not None


def broker_settings() -> tuple[str, int, int]:
    """`(host, port, keepalive)`。host 缺失即抛 `MissingEnv`，**没有内置默认地址**。"""
    host = require_env("MQTT_HOST")
    port = get_env_int("MQTT_PORT", DEFAULT_PORT)
    keepalive = get_env_int("MQTT_KEEPALIVE", 60)
    if port <= 0 or port > 65535:
        raise ValueError(f"MQTT_PORT 越界：{port}")
    return host, port, keepalive


def resolve_credentials(peer: str | None = None, *, allow_anonymous: bool = False) -> tuple[str, str] | None:
    """取 broker 凭据。缺一半视同没有——只带用户名不带口令等于匿名。

    键名收编现网两套：`MQTT_PASSWORD`（butler）与 `MQTT_PASS`（TVPilot / memory-agent）。
    """
    names = () if peer is None else (peer, peer_name(peer))
    users: list[str] = []
    passwords: list[str] = []
    for name in names:
        scoped = peer_name(name)
        users.append(f"MQTT_USER_{scoped}")
        passwords.append(f"MQTT_PASSWORD_{scoped}")
    users += ["MQTT_USER", "MQTT_USERNAME"]
    passwords += ["MQTT_PASSWORD", "MQTT_PASS", "MQTT_PASSWD"]
    user = first_env(tuple(users))
    password = first_env(tuple(passwords))
    if user is None and password is None:
        if allow_anonymous:
            return None
        raise MqttCredentialsMissing(
            "MQTT 凭据未配置：homesdk 不提供默认账密，也不做匿名回退。"
            "确实要匿名连再传 allow_anonymous=True"
        )
    if user is None or password is None:
        raise MqttCredentialsMissing("MQTT 用户名与口令不成套（缺一半视同匿名）")
    return user, password


def default_client_id(peer: str | None = None) -> str:
    """`homesdk-<peer>-<pid>`。

    现网 TVPilot 用裸 `Client()` 让 paho 自动造 id（同一进程重连会撞），
    memory-agent 用 `memory-agent-<epoch>`。显式带 pid 保证同机多实例不互踢。
    """
    suffix = peer_name(peer).lower() if peer else "app"
    return f"homesdk-{suffix}-{os.getpid()}"


def _new_client(client_id: str) -> Any:
    """按 paho 的实际形状构造，从新 API 往下试。

    只捕 `TypeError` / `ValueError`（参数不被接受），不捕 `Exception`：
    构造期真出错要原样冒出来，不能让探测逻辑把它咽成「再试一种写法」。
    """
    version = getattr(_paho, "CallbackAPIVersion", None)
    if version is not None:
        for kwargs in (
            {"callback_api_version": version.VERSION2, "client_id": client_id, "clean_session": False},
            {"callback_api_version": version.VERSION2, "client_id": client_id},
        ):
            try:
                return _paho.Client(**kwargs)
            except (TypeError, ValueError):
                continue
    return _paho.Client(client_id=client_id)


def get_client(
    client_id: str | None = None,
    *,
    peer: str | None = None,
    allow_anonymous: bool = False,
    qos: int = QOS,
) -> Any:
    """返回配好凭据与重连退避的 paho Client，**不连接**。

    用法（连接由调用方发起，`keepalive` 是 `connect` 的参数不是构造参数）：

        client = get_client(peer="butler")
        host, port, keepalive = broker_settings()
        client.connect(host, port, keepalive)
        client.loop_start()

    `qos` 只写进 `client._homesdk_qos` 供 `publish` 取默认值，不改变 paho 行为。
    """
    if _paho is None:
        raise MqttUnavailable("需要 paho-mqtt：pip install paho-mqtt（homesdk 本身不带它）")
    client = _new_client(client_id or default_client_id(peer))
    credentials = resolve_credentials(peer, allow_anonymous=allow_anonymous)
    if credentials is not None:
        client.username_pw_set(credentials[0], credentials[1])
    if hasattr(client, "reconnect_delay_set"):
        client.reconnect_delay_set(RECONNECT_MIN, RECONNECT_MAX)
    if not 0 <= qos <= 2:
        raise ValueError(f"QoS 只能是 0/1/2，收到 {qos}")
    client._homesdk_qos = qos
    return client


def publish(client: Any, topic: str, payload: Any = b"", *, qos: int | None = None, retain: bool = False) -> Any:
    """发布，默认 QoS 取 `get_client` 配的那个值（即 1）。

    刻意不做「未连接就自动 connect」：那会把网络调用藏进一个看起来纯本地的函数里，
    也是现网 TVPilot `mqtt_publish_cmds` 每次发自愈重连那条路径的成因。
    """
    if qos is None:
        qos = getattr(client, "_homesdk_qos", QOS)
    body = payload if isinstance(payload, (bytes, str)) else _json.dumps(payload, ensure_ascii=False)
    return client.publish(topic, body, qos=qos, retain=retain)
