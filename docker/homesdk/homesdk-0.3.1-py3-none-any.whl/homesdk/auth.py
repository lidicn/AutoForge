"""统一鉴权头构造与鉴权状态探测。

设计不变式：

    本模块内置的凭据数量恒等于 0。

没有兜底 token、没有默认口令、没有「未配置就按开发模式放行」。这条约束的存在理由
是现网量到的三个 fail-open 形状：DeskPilot `core/responses.py:52` 的内置兜底 token
（未配置即继续服务，只 warn 一次）、doubao2api `unified_server.py:714` 的空 key 直接 return、
AutoForge `af_api.py:231` 的 registry 关闭即全站公开（含写端点）。库如果再提供一个默认值，
就是把这三处偶然变成标准。

因此也**不存在全局回退 token**：`token_for("butler")` 拿不到 butler 的那一枚时返回 None，
不会退去读某个「万能」键。装上 homesdk 附带一枚密钥就在全生态畅通无阻，是本模块刻意做不到的事。

凭据每次现读，不缓存。现网两份反面教材都在 import 期读一次并驻留：
`butler.py:41`（DeskPilot）与 `tvpilot_server.py:146`（DOUBAO_API_KEY），
换密钥必须重启进程，而重启容器正是 `开发规范.md` §0 整机冻结的触发路径。
"""

from __future__ import annotations

import base64
from enum import Enum
from typing import Final, Mapping

from homesdk.config import MissingEnv, first_env, get_env
from homesdk.http import Response, join_url, peer_name, peer_url, request

#: 默认头名。值形如 `Bearer <token>`。
AUTHORIZATION: Final = "Authorization"

#: 旧仓已经在用的键名，收编进来好让下游不改 compose 就能接上。
#: 只登记**键名**，不登记任何值。 homesdk 自己的规范形是 `HOMESDK_TOKEN_<PEER>`，优先于这里。
LEGACY_TOKEN_KEYS: Final[Mapping[str, tuple[str, ...]]] = {
    "butler": ("BUTLER_TOKEN", "BUTLER_WEB_PASSWORD"),
    "memory-agent": ("MEMORY_AGENT_TOKEN", "MEMORY_AGENT_APP_TOKEN"),
    "tvpilot": ("TVPILOT_ADMIN_TOKEN", "TVPILOT_DEVICE_TOKEN"),
    "autoflow": ("AUTOFLOW_TOKEN",),
    "deskpilot": ("DESKPILOT_TOKEN",),
    "go2rtc": ("GO2RTC_TOKEN",),
}

#: 旧仓的人脸/流媒体侧口令对应用户名的键名，同样是键名。
LEGACY_USER_KEYS: Final[Mapping[str, tuple[str, ...]]] = {
    "go2rtc": ("GO2RTC_USER",),
    "memory-agent": ("MEMORY_AGENT_USER",),
}
LEGACY_PASS_KEYS: Final[Mapping[str, tuple[str, ...]]] = {
    "go2rtc": ("GO2RTC_PASS", "GO2RTC_PASSWORD"),
    "memory-agent": ("MEMORY_AGENT_PASS", "MEMORY_AGENT_PASSWORD"),
}


class AuthMissing(MissingEnv):
    """`require_*` 系列在凭据缺失时的出口。宽松系列返回 `{}`，严格系列抛这个。"""


class AuthCheck(Enum):
    """一次鉴权探测的结论。四种否定式各不合并——合并就分不清「没配」和「被拒」。"""

    #: 带上凭据拿到了 2xx。
    OK = "ok"
    #: 401/403：凭据带上了但不被接受（或被撤销）。
    REJECTED = "rejected"
    #: 本地就发现没有凭据，**没有发出任何请求**。
    NO_CREDENTIALS = "no-credentials"
    #: 连不上/超时/DNS：结论未知，不能当成通过，也不能当成被拒。
    UNREACHABLE = "unreachable"
    #: 服务端回了非 2xx 非 401/403（TVPilot 未配 token 时回 503 就落这里）。
    SERVER_ERROR = "server-error"

    def __bool__(self) -> bool:
        """只有 OK 为真。

        这条是 fail-open 的结构防线：`if check_auth(...)` 是这里最自然的误写，
        而枚举成员默认恒真——那会让「连不上」也走进成功分支。
        """
        return self is AuthCheck.OK

    @property
    def granted(self) -> bool:
        return self is AuthCheck.OK


def _token_keys(peer: str | None) -> tuple[str, ...]:
    if peer is None:
        return ("TOKEN",)
    name = peer_name(peer)
    legacy = tuple(LEGACY_TOKEN_KEYS.get(peer.strip().lower().replace("_", "-"), ()))
    legacy += tuple(LEGACY_TOKEN_KEYS.get(name.lower().replace("_", "-"), ()))
    return (f"TOKEN_{name}", *legacy)


def token_for(peer: str | None = None) -> str | None:
    """取某个对端的 token；没配就返回 None，**不回退到任何全局键**。"""
    return first_env(_token_keys(peer))


def auth_header_name(peer: str | None = None) -> str:
    """该对端要求的头名。默认 `Authorization`（Bearer 形态）。

    TVPilot 的 `/api/refresh` 认 `X-Admin-Token`、DeskPilot 认 `X-API-Token`、
    desktop_agent 认 `X-Agent-Token`——这些是各仓 compose 里的一行，不是库里的表：
    `HOMESDK_AUTH_HEADER_<PEER>=X-Admin-Token`。头名不是 `Authorization` 时
    值按原样放（不加 `Bearer ` 前缀）。
    """
    if peer is not None:
        scoped = get_env(f"AUTH_HEADER_{peer_name(peer)}")
        if scoped is not None:
            return scoped
    return get_env("AUTH_HEADER") or AUTHORIZATION


def get_auth_headers(peer: str | None = None) -> dict[str, str]:
    """宽松入口：拼鉴权头，没配凭据返回 `{}`。

    返回 `{}` 只适合「有就带、没有就不带」的读探测。要发一个**必须**带凭据的请求，
    用 `require_auth_headers`——空 dict 交给上面那几个 fail-open 服务端会静默成功。
    """
    token = token_for(peer)
    if token is None:
        return {}
    header = auth_header_name(peer)
    value = f"Bearer {token}" if header == AUTHORIZATION else token
    return {header: value}


def require_auth_headers(peer: str | None = None) -> dict[str, str]:
    """严格入口：缺凭据即抛 `AuthMissing`。发送前的自检用它。"""
    headers = get_auth_headers(peer)
    if not headers:
        raise AuthMissing(f"对端 {peer or '(未指名)'} 的 token 未配置：homesdk 不提供默认凭据")
    return headers


def _basic_credentials(peer: str) -> tuple[str, str] | None:
    name = peer_name(peer)
    legacy = peer.strip().lower().replace("_", "-")
    user = first_env((f"USER_{name}", *LEGACY_USER_KEYS.get(legacy, ())))
    password = first_env((f"PASSWORD_{name}", f"PASS_{name}", *LEGACY_PASS_KEYS.get(legacy, ())))
    if user is None or password is None:
        return None
    return user, password


def get_basic_headers(peer: str) -> dict[str, str]:
    """Basic 形态（go2rtc、memory-agent 的 `/api/vision/analyze`）。缺一半即 `{}`。"""
    pair = _basic_credentials(peer)
    if pair is None:
        return {}
    raw = f"{pair[0]}:{pair[1]}".encode("utf-8")
    return {AUTHORIZATION: "Basic " + base64.b64encode(raw).decode("ascii")}


def require_basic_headers(peer: str) -> dict[str, str]:
    """严格版 Basic：用户名或口令缺失即抛，避免发出一个退化成匿名的 Basic 请求。"""
    headers = get_basic_headers(peer)
    if not headers:
        raise AuthMissing(f"对端 {peer} 的 user/password 不成套（缺一半视同没有）")
    return headers


def _resolve_target(peer_or_url: str, path: str) -> str:
    if "://" in peer_or_url:
        return join_url(peer_or_url, path)
    return join_url(peer_url(peer_or_url), path)


def check_auth(
    peer_or_url: str,
    *,
    path: str = "/health",
    headers: Mapping[str, str] | None = None,
    timeout: float | None = None,
    opener=None,
) -> AuthCheck:
    """GET 一个健康/探测端点，判断凭据是否被接受。

    peer 形态（`check_auth("butler")`）走 `homesdk.http.peer_url` 解析地址；
    URL 形态（`check_auth("http://host:port", headers=...)`）原样使用。
    没配凭据时**不发请求**，直接返回 `NO_CREDENTIALS`——这是为了让调用方能把它
    和「服务活着但拒了我」区分开，也是本模块不碰网络的一条快路径。
    """
    if headers is not None:
        sent = dict(headers)
    elif "://" in peer_or_url:
        sent = get_auth_headers(None)
    else:
        sent = get_auth_headers(peer_or_url)
    if not sent:
        return AuthCheck.NO_CREDENTIALS
    url = _resolve_target(peer_or_url, path)
    sent_kwargs = {} if timeout is None else {"timeout": timeout}
    try:
        response: Response = request("GET", url, headers=sent, opener=opener, **sent_kwargs)
    except Exception:  # 连接层失败 → 未知，绝不折算成「通过」
        return AuthCheck.UNREACHABLE
    if response.is_2xx:
        return AuthCheck.OK
    if response.is_unauthorized:
        return AuthCheck.REJECTED
    return AuthCheck.SERVER_ERROR


def is_authenticated_ok(peer_or_url: str, **kwargs) -> bool:
    """布尔版 `check_auth`：只有真拿到 2xx 才 True。

    未配置凭据、被拒、连不上、服务端 5xx —— 四种否定式一律 False。
    要区分它们就改用 `check_auth`。
    """
    return check_auth(peer_or_url, **kwargs) is AuthCheck.OK
