"""生态内 HTTP 客户端：标准库 urllib、强制非零超时、**库内零私网地址**。

设计不变式：

    本模块不持有任何 host/端口/IP 字面量。

`butler_url()` 这类具名函数只是 `peer_url("butler")` 的薄封装，真值来自环境。
理由是取证量到的既成事实：memory-agent 已被推走的 `HEAD` 里就写着
`config.py:26`、`:30` 两条 `192.168.2.x:port` 字面量——把内网地图编进库默认值
在这个生态里不是假设。而 wheel 会被 vendor 进别的仓、pip 装进别的镜像、
按 sha256 登记成权威分发物，**未开源仓的内网拓扑会经开源仓的 vendor 目录单向带出去**。
所以地址留在各仓的 compose/.env，库只负责「怎么解析这个名字」。

新对端上线不需要 homesdk 发版：调用方的 compose 里加一行
`HOMESDK_PEER_<NAME>_URL=` 即可，见 `peer_url`。
"""

from __future__ import annotations

import json as _json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Final, Mapping

from homesdk.config import MissingEnv, get_env

#: 默认超时。取证现网值：MA face 3s、TVPilot go2rtc 2/5s、butler 各技能 5/8/10/15s。
#: 5s 是生态中位数，且可被 env 覆盖。
#: （本仓 `doc/生态链调用边表.md` 记了一条撤回：早先我断言「TVPilot 多处 urlopen 不传 timeout」，
#:  用 G5 那把尺复扫 `tvpilot_server.py` 的 16 处 `urlopen(` 全部带 `timeout=`——断言不成立。）
DEFAULT_TIMEOUT: Final = 5.0

_DEFAULT: Final = object()


class HttpError(RuntimeError):
    """连接层失败（DNS、拒绝、超时、TLS）。**永不返回「成功」的形状**。"""


class PeerUnknown(MissingEnv):
    """对端名字在环境里解析不出地址。继承 `MissingEnv`：调用方一个 except 就够。"""


@dataclass(frozen=True)
class Response:
    """一次应答。`status` 是唯一真相，本模块不替调用方判定成败。"""

    status: int
    reason: str
    headers: Mapping[str, str]
    body: bytes

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return _json.loads(self.text)

    @property
    def is_2xx(self) -> bool:
        return 200 <= self.status < 300

    @property
    def is_unauthorized(self) -> bool:
        return self.status in (401, 403)


def peer_name(peer: str) -> str:
    """`memory-agent` / `memory_agent` / `MemoryAgent` → `MEMORY_AGENT`。"""
    normalized = "".join(c if c.isalnum() else "_" for c in peer.strip()).strip("_").upper()
    if not normalized:
        raise PeerUnknown("对端名为空（strip 与规范化之后没有留下字母数字）")
    return normalized


def peer_url(peer: str) -> str:
    """按名字解析对端 base URL，去掉尾部斜杠。

    解析顺序（每一级都先试 `HOMESDK_` 前缀，再试裸名）：
    `PEER_<NAME>_URL` → `<NAME>_URL` → `<NAME>_BASE_URL`。
    第一种是 homesdk 的规范形；后两种让旧仓不改 compose 就能接上。
    一个都没有就抛 `PeerUnknown`——**不回退到内置地址**。
    """
    name = peer_name(peer)
    for key in (f"PEER_{name}_URL", f"{name}_URL", f"{name}_BASE_URL"):
        value = get_env(key)
        if value is not None:
            return value.rstrip("/")
    raise PeerUnknown(f"对端 {peer!r} 未配置地址（试了 {name} 的三种键名）")


def join_url(base: str, path: str = "") -> str:
    """拼 base 与 path，斜杠不重复也不缺失。"""
    if not path:
        return base.rstrip("/")
    return f"{base.rstrip('/')}/{path.lstrip('/')}"


def resolve_timeout(timeout: float | None | object = _DEFAULT) -> float:
    """定下本次超时秒数：显式参数 > `HOMESDK_HTTP_TIMEOUT` > `DEFAULT_TIMEOUT`。

    非正数一律拒绝，包括 `0`——`timeout=0` 在 socket 层是「立刻失败」，
    传它的人想要的几乎总是「不设限」，而「不设限」正是本模块禁止的。
    """
    if timeout is _DEFAULT:
        timeout = get_env("HTTP_TIMEOUT") or DEFAULT_TIMEOUT
    if timeout is None:
        raise ValueError("HTTP 超时不允许为 None（要默认就别传这个参数）")
    value = float(timeout)  # type: ignore[arg-type]
    if value <= 0:
        raise ValueError(f"HTTP 超时必须为正数秒，收到 {value!r}")
    return value


def _encode_body(body: Any) -> bytes | None:
    if body is None:
        return None
    if isinstance(body, bytes):
        return body
    if isinstance(body, str):
        return body.encode("utf-8")
    return _json.dumps(body, ensure_ascii=False).encode("utf-8")


def request(
    method: str,
    url: str,
    *,
    headers: Mapping[str, str] | None = None,
    body: Any = None,
    timeout: float | None | object = _DEFAULT,
    opener: Callable[..., Any] | None = None,
) -> Response:
    """发一次请求。`opener` 是给测试留的注入缝，默认 `urllib.request.urlopen`。

    4xx/5xx 走 `HTTPError` 返回，因为那是**服务端的答复**，不是失败：
    鉴权探测要把 401 和「连不上」分清楚，合并成一个异常就把两者糊在一起了。
    连接层失败抛 `HttpError`。
    """
    if not url.lower().startswith(("http://", "https://")):
        raise HttpError(f"不支持的 URL 形态：{url!r}（只接受 http/https）")
    data = _encode_body(body)
    merged = dict(headers or {})
    if data is not None and "Content-Type" not in merged and not any(k.lower() == "content-type" for k in merged):
        merged["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=data, headers=merged, method=method.upper())
    send = opener or urllib.request.urlopen
    seconds = resolve_timeout(timeout)
    try:
        with send(req, timeout=seconds) as raw:
            return Response(int(raw.status), str(raw.reason or ""), dict(raw.headers.items()), raw.read())
    except urllib.error.HTTPError as exc:
        payload = exc.read() if exc.fp is not None else b""
        return Response(int(exc.code), str(exc.reason), dict(exc.headers.items()) if exc.headers else {}, payload)
    except Exception as exc:  # 收口成一种异常，但**不吞**：带原因重新抛出
        raise HttpError(f"{method.upper()} {url} 失败：{type(exc).__name__}: {exc}") from exc


def get(url: str, **kwargs: Any) -> Response:
    """`GET`。参数同 `request`。"""
    return request("GET", url, **kwargs)


def post(url: str, body: Any = None, **kwargs: Any) -> Response:
    """`POST`。dict/list 自动 JSON 编码并补 `Content-Type`。"""
    return request("POST", url, body=body, **kwargs)


def butler_url() -> str:
    """doubao-butler 指令中心。"""
    return peer_url("butler")


def tvpilot_url() -> str:
    """TVPilot 电视端。"""
    return peer_url("tvpilot")


def face_url() -> str:
    """人脸节点（Arcface）。

    注意：memory-agent 侧还有一份运行时自注册的节点表（`face_node_registry.py`，
    进程内 dict、TTL 120s、同 node_id 再注册即整体覆盖 url）。那份表才是「当前有哪个
    节点活着」的真相，本函数只给「默认去哪个地址」——两者不一致时以注册表为准。
    """
    return peer_url("face")


def go2rtc_url() -> str:
    """go2rtc 流媒体。"""
    return peer_url("go2rtc")


def ma_url() -> str:
    """memory-agent。"""
    return peer_url("memory-agent")
